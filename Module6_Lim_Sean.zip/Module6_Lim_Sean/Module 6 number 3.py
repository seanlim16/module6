import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.stats import chi2_contingency

# Load data from CSV file
dat = pd.read_csv("Covid_19_Deaths_Race.csv")
print('Data:(Rows, Columns)')
print(dat.shape)
dat.head(5)

#The first line of code below creates a new dataset, df, that contains only the numeric variables
df = dat[['OBJECTID','DATE','African_American','White','Hispanic','Asian','Other','Not_Available']]
df2 = dat[['African_American','White','Hispanic']]

#plot chart, second line creates the plot, where the argument kind="scatter" creates the plot without the regression line. 
sns.pairplot(df, kind="scatter")
plt.show()

#pearson correlation coefficient
print('\n Correlation - Pearson Correlation Coefficient')
print(df2.corr())
plt.title('Covid-19 African American vs. White vs. Hispanic Death Correlation')
plt.scatter(dat.African_American,dat.White,dat.Hispanic)
plt.xlabel('Deaths')
plt.ylabel('Deaths')
plt.show()

#Chi-Square Test of Independence
print('\n Correlation - Chi-Square Test of Independence')
print('1. African American vs. White Deaths in Maryland:')
print(chi2_contingency(pd.crosstab(dat.African_American,dat.White)))
print('P = 0.0699796419956736')
print('0.0699796419956736 > 0.05 = Strong Relationship')
plt.title('Covid-19 African American vs. White Death Correlation')
plt.scatter(dat.African_American,dat.White)
plt.xlabel('Deaths')
plt.ylabel('Deaths')
plt.show()

#Chi-Square Test of Independence
print('\n2 White vs. Hispanic:')
print(chi2_contingency(pd.crosstab(dat.White,dat.Hispanic)))
print('P = 0.09224648606347202')
print('0.09224648606347202 > 0.05 = Strong Relationship')
plt.title('Covid-19 White vs. Hispanic Death Correlation')
plt.scatter(dat.White,dat.Hispanic)
plt.xlabel('Deaths')
plt.ylabel('Deaths')
plt.show()

#Chi-Square Test of Independence
print('\n3 African American vs. Hispanic:')
print(chi2_contingency(pd.crosstab(dat.African_American,dat.Hispanic)))
print('P = 1.2867599650791443e-11')
print('1.2867599650791443e-11 < 0.05 = Weak Relationship')
plt.title('Covid-19 African American vs. Hispanic Death Correlation')
plt.scatter(dat.African_American,dat.Hispanic)
plt.xlabel('Deaths')
plt.ylabel('Deaths')
plt.show()