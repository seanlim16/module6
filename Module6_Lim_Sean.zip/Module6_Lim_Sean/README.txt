Sean Lim | Module 6 = Data Science Concepts
Version 1.0 | Stable Version 1.0 | Last Updated 04/15/21
---------------------------------------------------------
The main python code fullfills:
1 - Trend Prediction (module 6 number 1)
3 - Data relationship (module 6 number 3)
With help from Matthew and Michael we finished module 6
---------------------------------------------------------
The main program EE 104 Module 6 is complete and fully functional
---------------------------------------------------------
These are the utilized libraries for this module:
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.stats import chi2_contingency
from sklearn.preprocessing import MinMaxScaler, StandardScaler
import math
from keras.models import Sequential
from keras.layers import Dense, LSTM
---------------------------------------------------------
In the trend prediction portion of this module I plotted the number of cases from
March to may and then used a training and test set (machine learning) to show a prediction
of approximately how many cases of COVID-19 there could be. Using the CSV file from
https://covidtracking.com/data/state/california a training set and testing set was created
to do a prediction of cases.In the first part of the code the csv is read and plotted and then
it is read again in order to make a training set which was then used to make a prediction based on
the 3 months. The prediction is very different than the actual outcome because the values used
were from the beginning of the pandemic in March of 2020. In the US the numbers started out fairly moderate,
but due to poor regulation and quarentining the numbers rose exponentially.

In the data relationship portion of this module it can be seen that the COVID-19
virus has been the cause of death for many people of different races. According to the
Pearson Correlation Coefficient and Chi-Square Test of Independance we can see that
the amount of COVID-19 related deaths does not correlate to a particular persons race.
It would seem that no matter the background, COVID-19 has been lethal to all people
equally.
---------------------------------------------------------
https://catalog.data.gov/dataset?q=CA+covid&sort=score+desc%2C+name+asc&as_sfid=AAAAAAXIr2cOAXO4R8QrnmHLCSRr12aNEEHoeig2RZSwLRY1WTRt-vm0GS0dSRQUtbZx_CuHsaLtkh8hS9jaOTYvP2ZISGn7R79BThtg98hLaA9P4UvBavjYQVoSWgsO4ltCTxc%3D&as_fid=d377bbff326333e1df2bbaa488da789729fe9097&ext_location=&ext_bbox=&ext_prev_extent=-141.6796875%2C8.754794702435618%2C-59.4140625%2C61.77312286453146
https://www.youtube.com/watch?v=QIUxPv5PJOY
https://covidtracking.com/data/state/california
https://guides.lib.berkeley.edu/publichealth/healthstatistics/rawdata